package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	private IFlatRegistrationDAO flatDAO = new FlatRegistrationDAOImpl();
	/*
	 * dao to service layer
	 * @see com.cg.frs.service.IFlatRegistrationService#registerFalt(com.cg.frs.dto.FlatRegistrationDTO)
	 */
	@Override
	public FlatRegistrationDTO registerFalt(FlatRegistrationDTO flat)
			throws FlatRegistrationException {
		
		if(flatDAO.getOwnerIds().contains(flat.getOwner_id())){
			if((flat.getFlat_type()==1)||flat.getFlat_type()==2){
				FlatRegistrationDTO flat1= flatDAO.registerFalt(flat);
			
			return flat1;
		}else{
			throw new FlatRegistrationException("Enter valid flat type");
		}
		}
	else{
		throw new FlatRegistrationException("Enter valid owner id");
			
		}
	
	}
	/*
	 * dao to service
	 * @see com.cg.frs.service.IFlatRegistrationService#getOwnerIds()
	 */

	@Override
	public ArrayList<Integer> getOwnerIds() throws FlatRegistrationException {
		ArrayList<Integer> list = flatDAO.getOwnerIds();
		
		return list;
	}
	

}
