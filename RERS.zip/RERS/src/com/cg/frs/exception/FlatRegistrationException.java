package com.cg.frs.exception;

public class FlatRegistrationException extends Exception {
	String message;

	public FlatRegistrationException() {
		super();
	}

	public FlatRegistrationException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "FlatRegistrationException message=" + message;
	}
	

}
